import { ChangeDetectorRef, Component, ElementRef, ViewChild } from '@angular/core';
import { DataService } from '../services/data.service';
import { GlobalConstants } from '../services/global.constant';
import { NotificationService } from '../services/notification.service';
import { CommonModule, NgIf, NgFor } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { DialogModule } from 'primeng/dialog';
import { FloatLabelModule } from 'primeng/floatlabel';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressBarModule } from 'primeng/progressbar';
import { RatingModule } from 'primeng/rating';
import { RippleModule } from 'primeng/ripple';
import { SelectModule } from 'primeng/select';
import { SliderModule } from 'primeng/slider';
import { TableModule } from 'primeng/table';
import { TagModule } from 'primeng/tag';
import { ToastModule } from 'primeng/toast';
import { ToggleButtonModule } from 'primeng/togglebutton';
import { ToggleSwitchModule } from 'primeng/toggleswitch';
import { Addproduct } from './addproduct/addproduct';
import { Editproduct } from './editproduct/editproduct';
import { ConfigService } from '../services/config.service';
import { HttpService } from '@/service/http.service';
import { ToastvalueService } from '../services/toastvalue.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-product',
  imports: [TableModule,
    MultiSelectModule,
    SelectModule,
    InputIconModule,
    TagModule,
    InputTextModule,
    SliderModule,
    ProgressBarModule,
    ToggleButtonModule,
    ToastModule,
    CommonModule,
    FormsModule,
    ButtonModule,
    RatingModule,
    RippleModule,
    IconFieldModule,
    DialogModule,
    FloatLabelModule,
    DatePickerModule,
    ToggleSwitchModule, NgIf, NgFor, Addproduct, Editproduct],
  templateUrl: './product.html',
  styleUrl: './product.scss'
})
export class Product {

  addenable: boolean = false;
  display: boolean = false;
  editenable: boolean = false;
  editdisplayproduct: boolean = false;

  floatValue: any = null;
  getproductist: any;
  loading: boolean = true;
  selectedProduct: any = null;

  clearButtonEnabled: boolean = false;
  currentFilter: any = {};
  currentSort: any = null;
  filterApplied: boolean = false;
  sortApplied: boolean = false;

  globalFilter: string = '';
  selectedRange: Date[] = [];
  startdate: any;
  enddate: any;

  @ViewChild('filter') filter!: ElementRef;
  data: any;
  productdata: any;
  isFilterVisible: { [key: string]: boolean } = {};

  userdatavalue: any[] = [];
  userid: string = '';

  productList: any[] = [];

  userFields: string[] = [
  'categoryname',
  'productname',
  'prod_code',
  'prod_name',
  'prod_price',
  'prod_grpcod',
  'is_active'
];

userUiFields: string[] = [
  'Category',
  'product',
  'Product Code',
  'Product Name',
  'Price',
  'Group Code',
  'Status'
];

   constructor(
      private HTTPSERVICE: HttpService,
      private CDR: ChangeDetectorRef,
      private navigation: Router,
      private toasterService: ToastvalueService,
      private CONFIGSERVICE: ConfigService,
      private notificationService: NotificationService,
      private dataService: DataService,
    ) { }

  ngOnInit() {
    this.getProducts();
  }

  // ✅ GET PRODUCTS
  getProducts() {
    let url = GlobalConstants.Authurl + GlobalConstants.Getproduct;

    this.dataService.getData(url).subscribe((res: any) => {
      if (res.status === 'success') {
        this.productList = res.response.ref1;
      } else {
        this.notificationService.showMessage('error', 'Error', 'No data');
      }
      this.loading = false;
      this.CDR.detectChanges();
    });
  }

  // ✅ ADD
  openAdd() {
    this.addenable = true;
    this.display = true;
  }

  onReload() {
    this.addenable = false;
    this.getProducts();
  }

  // ✅ DELETE
  deleteProduct(id: number) {

    let url = GlobalConstants.Authurl + GlobalConstants.Deleteproduct;

    const input = { productid: id };

    this.dataService.addData(url, input).subscribe((res: any) => {
      if (res.status === 'success') {
        this.getProducts();
        this.notificationService.showMessage('success', 'Deleted', 'Product deleted');
      }
    });
  }

  // ✅ EDIT (optional)
  editProduct(row: any) {
    console.log(row);
  }

  backtomainChange(event: any) {
    if (event === false) {
      this.editdisplayproduct = true;
      this.editenable = false;
      this.getproduct();
      this.CDR.detectChanges();
    }
  }

  onDataReloaded() {
    this.addenable = false;
    this.getproduct();
  }
  formatDateWithCustomTime(date: Date, hours: number, minutes: number, seconds: number): string {
    date.setHours(hours, minutes, seconds, 0); // set time
    const year = date.getFullYear();
    const month = (`0${date.getMonth() + 1}`).slice(-2);
    const day = (`0${date.getDate()}`).slice(-2);
    const h = (`0${date.getHours()}`).slice(-2);
    const m = (`0${date.getMinutes()}`).slice(-2);
    const s = (`0${date.getSeconds()}`).slice(-2);

    return `${year}-${month}-${day} ${h}:${m}:${s}`;
  }

  onDateRangeSelected(range: any) {

    this.selectedRange = range;

    if (this.checkInputIsValid(this.selectedRange)) {
      this.startdate = this.formatDateWithCustomTime(new Date(this.selectedRange[0]), 0, 0, 0);
      this.enddate = this.formatDateWithCustomTime(new Date(this.selectedRange[1]), 23, 59, 59);

      this.onDataReloaded();
    }
  }

  onGlobalFilter(table: any, event: any) {
    const value = event.target.value;
    this.globalFilter = value;
    table.filterGlobal(value, 'contains');

    if (this.checkInputIsValid(this.globalFilter)) {
      this.filterApplied = true;
    }
    else {
      this.filterApplied = false;
    }
  }

  clearFilter(table: any) {
    this.globalFilter = '';
    table.clear();
    this.filterApplied = false;
  }

  onFilter(event: any) {

    const filterEntries: [string, [{ value: any; matchMode: string; operator: string }]][] = Object.entries(event.filters);
    const filteredEntries = filterEntries.filter(([key, data]) => {
      return data[0].value !== null && data[0].value.trim() !== '';
    });

    if (filteredEntries.length > 0) {
      this.currentFilter = filteredEntries[0][1][0].value;
    }
    else {
      this.currentFilter = {};
    }

    if (Object.keys(this.currentFilter).length > 0) {
      //this.filterApplied = true;
      this.clearButtonEnabled = true;
    }
    else {
      this.filterApplied = false;
      this.clearButtonEnabled = false;
    }



  }

  onSort(event: any) {
    if (this.checkInputIsValid(event.order)) {
      this.clearButtonEnabled = true;
    }
    else {
      this.clearButtonEnabled = false;
    }

    const field = event.field;  // The field that is being sorted
    const order = event.order;

    this.getproductist.sort((a: any, b: any) => {
      if (a[field] < b[field]) {
        return order === 1 ? -1 : 1; // Ascending or descending
      }
      if (a[field] > b[field]) {
        return order === 1 ? 1 : -1; // Ascending or descending
      }
      return 0;
    });
  }

  clear(table: any) {
    table.clear();
    this.clearButtonEnabled = false;
  }

  checkInputIsValid(inputValue: any) {
    if (inputValue !== undefined && inputValue !== null && inputValue !== '')
      return true;
    else
      return false;
  }

  toggleSearchBox(field: string) {
    this.isFilterVisible[field] = !this.isFilterVisible[field];
  }
  exportToExcel(): void {
    // Get the table instance
    const table = this.dt1; // Make sure dt1 is a ViewChild reference

    // Get filtered data if available, otherwise fallback to all data
    const dataToExport = table.filteredValue ? table.filteredValue : this.getproductist;

    // Prepare the data
    const dataWithHeaders = [
      this.userUiFields,  // header row
      ...dataToExport.map((row: any) => this.userFields.map(field => row[field]))
    ];

    // Create worksheet and workbook
    // const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(dataWithHeaders);
    // const wb: XLSX.WorkBook = XLSX.utils.book_new();
    // XLSX.utils.book_append_sheet(wb, ws, 'product');

    // // Export
    // XLSX.writeFile(wb, 'product.xlsx');
  }


  openAddproductDialog() {
    this.addenable = true;
    this.editenable = false;
    this.display = true;
    this.CDR.detectChanges();
  }

  closeAddproductDialog() {
    this.display = false;
  }

  editscreen(productdata: any) {
    this.addenable = false;
    this.editenable = true;
    this.editdisplayproduct = true;
    this.display = false;
    this.productdata = productdata;
    //this.selectedProduct = { ...product };
    this.CDR.detectChanges();
  }

  getproduct() {

    //let url = this.CONFIGSERVICE.getApi('AUTH_URL') + GlobalConstants.Getsubcategory;
    let url = GlobalConstants.Authurl + GlobalConstants.Getsubcategory;

    this.dataService.getData(url).subscribe(
      (response: any) => {
        console.log(response);
        if (response.status == 'success') {
          this.productdata = response['response']['ref1'];
          this.CDR.detectChanges();
        }
        else {
          this.notificationService.showMessage('error', 'Error', 'There is no data .');
        }
      });

  }

}
