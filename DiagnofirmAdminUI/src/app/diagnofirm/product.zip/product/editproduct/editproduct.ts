import { Component } from '@angular/core';

@Component({
  selector: 'app-editproduct',
  imports: [],
  templateUrl: './editproduct.html',
  styleUrl: './editproduct.scss'
})
export class Editproduct {

}
