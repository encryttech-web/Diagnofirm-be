import { DataService } from '@/diagnofirm/services/data.service';
import { GlobalConstants } from '@/diagnofirm/services/global.constant';
import { NotificationService } from '@/diagnofirm/services/notification.service';
import { ChangeDetectorRef, Component, EventEmitter, Input, Output } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-addproduct',
  imports: [],
  templateUrl: './addproduct.html',
  styleUrl: './addproduct.scss'
})
export class Addproduct {

  @Input() display: boolean = false;
  @Output() displayChange = new EventEmitter<boolean>();

  // DROPDOWNS
  categoryList: any[] = [];
  subcategoryList: any[] = [];
  healthList: any[] = [];
  orgList: any[] = [];

  // FORM VALUES
  category: number | null = null;
  subcategory: number | null = null;
  health: number | null = null;
  org: number | null = null;

  prod_code = '';
  prod_name = '';
  prod_desc = '';
  prod_price: number | null = null;
  prod_grpcod = '';

  imageFile: File | null = null;
  imagePreview: any = null;
  getsubcategoryist: any;
  getcategoryist: any;

  constructor(
    private dataService: DataService,
    private notificationService: NotificationService,
    private CDR: ChangeDetectorRef,
  ) { }

  ngOnInit() {
    this.loadDropdowns();
  }

  loadDropdowns() {
    // call APIs here
    this.getcategory();

  }

  getcategory() {

    //let url = this.CONFIGSERVICE.getApi('AUTH_URL') + GlobalConstants.Getcategory;
    let url = GlobalConstants.Authurl + GlobalConstants.Getcategory;

    this.dataService.getData(url).subscribe((response: any) => {
      if (response.status == 'success') {
        this.getcategoryist = response['response']['ref1'];
        this.CDR.detectChanges();
      }
      else {
        this.notificationService.showMessage('error', 'Error', 'There is no data .');
      }
    });

  }

  onCategoryChange(event: any) {
    const categoryId = event.value;

    // clear previous selection
    this.subcategory = null;
    this.subcategoryList = [];

    this.getsubcategorybycatgoryId(categoryId);
  }

  getsubcategorybycatgoryId(categoryId: any) {

    const input = {
      categoryid: Number(categoryId)
    }

    //let url = this.CONFIGSERVICE.getApi('AUTH_URL') + GlobalConstants.GetsubcategorybyCategoryId;
    let url = GlobalConstants.Authurl + GlobalConstants.GetsubcategorybyCategoryId;

    this.dataService.addData(url, input).subscribe(
      (response: any) => {
        console.log(response);
        if (response.status == 'success') {
          this.subcategoryList = response['response']['ref1'];
          this.CDR.detectChanges();
        }
        else {
          this.notificationService.showMessage('error', 'Error', 'There is no data .');
        }
      });

  }

  // IMAGE
  onImageSelect(event: any) {
    if (event.files?.length) {
      this.imageFile = event.files[0];

      const reader = new FileReader();
      reader.onload = () => this.imagePreview = reader.result;
      if (!this.imageFile) {
        this.notificationService.showMessage(
          'error',
          'Image Required',
          'Please upload an image'
        );
        return;
      }
      reader.readAsDataURL(this.imageFile);
    }
  }

  // SAVE
  addbtn(form: NgForm) {

    if (!form.valid || !this.imageFile) {
      this.notificationService.showMessage('error', 'Error', 'Fill all fields');
      return;
    }

    const formData = new FormData();

    formData.append('cat_id', String(this.category));
    formData.append('subcat_id', String(this.subcategory));
    formData.append('hlthcndtn_id', String(this.health));
    formData.append('org_id', String(this.org));

    formData.append('prod_code', this.prod_code);
    formData.append('prod_name', this.prod_name);
    formData.append('prod_desc', this.prod_desc);
    formData.append('prod_price', String(this.prod_price));
    formData.append('prod_grpcod', this.prod_grpcod);

    // IMPORTANT
    formData.append('prod_image', this.imageFile);

    this.dataService.addData('YOUR_API_URL', formData)
      .subscribe((res: any) => {

        if (res.status === 'success') {
          this.notificationService.showMessage('success', 'Saved', 'Product added');
          this.close();
        } else {
          this.notificationService.showMessage('error', 'Error', 'Failed');
        }

      });
  }

  clear() {
    this.prod_code = '';
    this.prod_name = '';
    this.prod_desc = '';
    this.prod_price = null;
    this.prod_grpcod = '';

    this.imageFile = null;
    this.imagePreview = null;
  }

  close() {
    this.display = false;
    this.displayChange.emit(false);
  }

}
